# ALTHERIA Adventure — Android v1.0

Port móvel do projeto Altheria Adventure.

Conteúdo embarcado: 6.200 eventos, 1.000 habilidades Elyth, 500 feitiços, 800 monstros, 240 fauna, 1.200 Renegados, 4.000+ NPCs e transportes.

Motor: Java 17+ / Android.
UI: Android nativo, sem dependências externas de UI.

**Status:** projeto Android pronto para build; o ambiente desta conversa não possui Android SDK/Build Tools instalados, então o APK binário não foi gerado aqui.
