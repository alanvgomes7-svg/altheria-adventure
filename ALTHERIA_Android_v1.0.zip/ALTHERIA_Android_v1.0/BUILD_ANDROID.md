# ALTHERIA Adventure — Android

Este projeto é a versão Android do motor narrativo de Altheria. Ele reutiliza o banco de conteúdo TSV da versão desktop e oferece uma interface nativa para celular.

## Build com Android Studio

1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Use **Build > Build APK(s)**.
4. O APK de depuração será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Build pelo GitHub Actions

O repositório inclui `.github/workflows/android.yml`. Em um repositório GitHub, basta executar o workflow **Build Altheria APK**. O artefato `altheria-adventure-debug-apk` conterá o APK.

A documentação oficial do Android recomenda `assembleDebug` para gerar um APK de depuração rapidamente; builds de release precisam ser assinados com a chave do desenvolvedor.
